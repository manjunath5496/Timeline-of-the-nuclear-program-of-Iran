#!/bin/bash
#AR Takahashi
#04.05.04
rm -rf raw_energy.txt
for i in `ls PbTiO3.out.*`
do
  grep -H "\!" $i | tail -1 >> raw_energy_results.txt
done
