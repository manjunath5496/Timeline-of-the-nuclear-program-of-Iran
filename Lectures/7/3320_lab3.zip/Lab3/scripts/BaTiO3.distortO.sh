#!/bin/sh
# This script will sweep through the oxygen displacements of BaTiO3
# to find the stablest tetragonal phase 
for distort in 502 504 506 508 510 512 514 516 518 520
do
rm -rf *.pot *.rho *.save *.wfc *.igk
cat > BaTiO3.in << EOF
 &control
    calculation = 'relax',
    restart_mode = 'from_scratch',
    prefix = 'BaTiO3.distortO',
    tstress = .true.,
    tprnfor = .true.,
    pseudo_dir = '/home/brandonw/LAB3/',
    outdir='/home/brandonw/LAB3/'
 /
 &system
    ibrav =  1, 
    celldm(1) = 7.52, 
    nat =  5, 
    ntyp = 3,
    ecutwfc = 30.0,
    ecutrho = 240.0
 /
 &electrons
    diagonalization='cg',
    mixing_mode = 'plain',
    mixing_beta = 0.7,
    conv_thr =  1.0d-8
 /
 &ions
    ion_dynamics='bfgs'
 /

ATOMIC_SPECIES
 Ba 137.327 Ba.UPF
 Ti 47.88   Ti.UPF
 O  15.9994 O.UPF

ATOMIC_POSITIONS
 Ba 0.0 0.0 0.0 0 0 0
 Ti 0.5 0.5 0.$distort 0 0 0
 O 0.5 0.5 0
 O 0.5 0.0 0.5
 O 0.0 0.5 0.5

K_POINTS automatic
  4 4 4 1 1 1
EOF

./pw.x < BaTiO3.in > BaTiO3_distortO.$distort.out
done
