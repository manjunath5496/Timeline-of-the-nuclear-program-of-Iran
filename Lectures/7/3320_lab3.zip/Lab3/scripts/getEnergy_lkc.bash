#!/bin/bash
#AR Takahashi
# This script will extract final energies from pwscf output files
grep "\!" *.out.* | sed 's/Fe[bf]cc\.out\.lattice-//' |sed 's/\.kpts-/ /' |sed 's/\.cutoff-/ /'| sed 's/:\!//'| sed 's/total energy//' | sed 's/=//' | sed 's/ryd//' 


